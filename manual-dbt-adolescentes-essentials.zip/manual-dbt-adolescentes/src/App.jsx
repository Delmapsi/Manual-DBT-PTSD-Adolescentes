import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { ChevronRight, Heart, Brain, Shield, Sparkles, Users, Home } from 'lucide-react'
import diagramaFases from './assets/dbt_phases_flowchart.png'
import './App.css'

function App() {
  const [currentPhase, setCurrentPhase] = useState(0)

  const phases = [
    {
      id: 0,
      title: "Bienvenida",
      icon: <Home className="w-8 h-8" />,
      color: "from-purple-500 to-pink-500",
      content: (
        <div className="space-y-6">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            ¡Hola! Tu Guía para Entender y Manejar Emociones Fuertes
          </h2>
          <p className="text-lg text-muted-foreground">
            ¿Alguna vez te has sentido abrumado por tus emociones? ¿Como si una ola gigante te arrastrara y no supieras cómo salir a flote? Es normal. La vida adolescente puede ser un torbellino de sentimientos, y a veces, después de experiencias difíciles, esos sentimientos pueden volverse aún más intensos y confusos.
          </p>
          <p className="text-lg">
            Este manual es tu compañero en un viaje para entenderte mejor, manejar esas emociones fuertes y construir una vida que realmente valga la pena vivir. Se basa en algo llamado <strong>DBT-PTSD</strong>, que es como un kit de herramientas súper útil para adolescentes que han pasado por cosas difíciles.
          </p>
          <div className="grid md:grid-cols-2 gap-4 my-8">
            <Card className="border-purple-200 dark:border-purple-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-500" />
                  Lo que aprenderás
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p>✨ Entender por qué sientes lo que sientes</p>
                <p>🛠️ Aprender a manejar el estrés y la ansiedad</p>
                <p>💪 Construir relaciones más sanas</p>
                <p>🌟 Descubrir tus fortalezas</p>
                <p>🎯 Crear un futuro donde te sientas seguro y feliz</p>
              </CardContent>
            </Card>
            <Card className="border-pink-200 dark:border-pink-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-pink-500" />
                  ¿Qué es el TEPT Complejo?
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p>Cuando has vivido experiencias difíciles por mucho tiempo, tu cerebro y cuerpo pueden reaccionar de formas que son difíciles de manejar.</p>
                <p className="text-sm text-muted-foreground mt-2">Pero hay buenas noticias: este manual te dará herramientas para cambiar eso y sentirte mejor.</p>
              </CardContent>
            </Card>
          </div>
          <img src={diagramaFases} alt="Diagrama de Fases" className="w-full rounded-lg shadow-lg my-8" />
        </div>
      )
    },
    {
      id: 1,
      title: "Fase 1: Compromiso",
      icon: <Shield className="w-8 h-8" />,
      color: "from-blue-500 to-cyan-500",
      content: (
        <div className="space-y-6">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            ¡Manos a la Obra! El Compromiso
          </h2>
          <p className="text-lg">Esta fase es como el calentamiento antes de un entrenamiento. Nos preparamos, entendemos las reglas del juego y nos comprometemos a dar lo mejor de nosotros.</p>
          
          <Card className="border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle>Módulo 1.2: Tu Historia, Tu Fuerza</CardTitle>
              <CardDescription>Ejercicio Práctico: Mi Línea de Vida</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Imagina que tu vida es una línea de tiempo. Desde que naciste hasta hoy. En un papel grande o en una pizarra, dibuja esa línea.</p>
              <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg space-y-2">
                <p>🎨 Marca los momentos más importantes de tu vida</p>
                <p>🌈 Usa diferentes colores para momentos felices y desafiantes</p>
                <p>💭 Reflexiona: ¿Qué aprendiste? ¿Quiénes estuvieron contigo?</p>
                <p>💪 ¿Qué fortalezas descubriste en ti?</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-cyan-200 dark:border-cyan-800">
            <CardHeader>
              <CardTitle>Módulo 1.4: Mindfulness y Compasión</CardTitle>
              <CardDescription>Ejercicio Práctico: La Respiración del Ancla</CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3 list-decimal list-inside">
                <li>Siéntate cómodamente o acuéstate</li>
                <li>Cierra los ojos suavemente si te sientes a gusto</li>
                <li>Lleva tu atención a tu respiración</li>
                <li>Siente cómo el aire entra y sale de tu cuerpo</li>
                <li>Cuando tu mente se distraiga, tráela de vuelta a tu respiración</li>
                <li>Haz esto por 2-5 minutos</li>
              </ol>
              <p className="mt-4 text-sm text-muted-foreground italic">Tu respiración es tu ancla, siempre está ahí para ti. ¡Verás qué bien te sientes!</p>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 2,
      title: "Fase 2: Trauma y Motivación",
      icon: <Brain className="w-8 h-8" />,
      color: "from-green-500 to-emerald-500",
      content: (
        <div className="space-y-6">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
            Entendiendo el Trauma y Encontrando tu Motivación
          </h2>
          <p className="text-lg">Vamos a explorar cómo las experiencias difíciles pueden afectar tu vida y, lo más importante, cómo puedes encontrar la fuerza para superarlas.</p>
          
          <Card className="border-green-200 dark:border-green-800">
            <CardHeader>
              <CardTitle>Módulo 2.4: El Viejo Camino y el Nuevo Camino</CardTitle>
              <CardDescription>Ejercicio Práctico: ¿Qué Camino Eliges?</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-red-50 dark:bg-red-950 p-4 rounded-lg">
                  <h4 className="font-bold mb-2">🚫 El Viejo Camino</h4>
                  <ul className="space-y-1 text-sm">
                    <li>• ¿Qué sientes?</li>
                    <li>• ¿Qué piensas?</li>
                    <li>• ¿Qué haces?</li>
                    <li>• ¿Cuáles son las consecuencias?</li>
                  </ul>
                </div>
                <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg">
                  <h4 className="font-bold mb-2">✅ El Nuevo Camino</h4>
                  <ul className="space-y-1 text-sm">
                    <li>• ¿Qué te gustaría sentir?</li>
                    <li>• ¿Qué pensarías diferente?</li>
                    <li>• ¿Qué harías diferente?</li>
                    <li>• ¿Consecuencias positivas?</li>
                  </ul>
                </div>
              </div>
              <p className="mt-4 font-semibold text-center">Tienes el poder de elegir y construir un Nuevo Camino que te lleve a donde quieres estar.</p>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 3,
      title: "Fase 3: Habilidades",
      icon: <Sparkles className="w-8 h-8" />,
      color: "from-yellow-500 to-orange-500",
      content: (
        <div className="space-y-6">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
            Desarrollando tus Súper Poderes Mentales
          </h2>
          <p className="text-lg">Aquí vas a aprender habilidades prácticas que te ayudarán a manejar tus emociones, pensamientos y reacciones de una manera mucho más efectiva.</p>
          
          <Card className="border-yellow-200 dark:border-yellow-800">
            <CardHeader>
              <CardTitle>Módulo 3.1: Habilidades Anti-Desconexión</CardTitle>
              <CardDescription>Ejercicio Práctico: Anclaje al Presente con los 5 Sentidos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <span className="text-2xl">👀</span>
                  <div>
                    <strong>5 cosas que puedes ver:</strong> Mira a tu alrededor y nombra cinco cosas. Obsérvalas con detalle.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">✋</span>
                  <div>
                    <strong>4 cosas que puedes tocar:</strong> Toca cuatro objetos y siente su textura, temperatura, peso.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">👂</span>
                  <div>
                    <strong>3 cosas que puedes oír:</strong> Escucha atentamente y nombra tres sonidos.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">👃</span>
                  <div>
                    <strong>2 cosas que puedes oler:</strong> Identifica dos olores a tu alrededor.
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-2xl">👅</span>
                  <div>
                    <strong>1 cosa que puedes saborear:</strong> Presta atención al sabor en tu boca.
                  </div>
                </div>
              </div>
              <p className="mt-4 text-sm text-muted-foreground italic">Este ejercicio te ayuda a anclarte en el aquí y ahora, usando tus sentidos.</p>
            </CardContent>
          </Card>

          <Card className="border-orange-200 dark:border-orange-800">
            <CardHeader>
              <CardTitle>Módulo 3.2: Aguantando el Chaparrón</CardTitle>
              <CardDescription>Ejercicio Práctico: La Ola de la Emoción</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Cuando sientas una emoción muy fuerte, imagínala como una ola en el océano:</p>
              <div className="bg-orange-50 dark:bg-orange-950 p-4 rounded-lg space-y-2">
                <p>🌊 Al principio, la ola es pequeña</p>
                <p>📈 Luego crece</p>
                <p>⛰️ Alcanza su punto máximo</p>
                <p>📉 Finalmente disminuye</p>
              </div>
              <p className="mt-4 font-semibold">Tu tarea es surfear esa ola sin ahogarte. Solo obsérvala, respira y recuerda que, como todas las olas, pasará.</p>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 4,
      title: "Fase 6: Vida que Vale la Pena",
      icon: <Heart className="w-8 h-8" />,
      color: "from-red-500 to-rose-500",
      content: (
        <div className="space-y-6">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">
            Construyendo una Vida que Amas
          </h2>
          <p className="text-lg">¡Esta es la fase donde empiezas a diseñar tu futuro! Es momento de enfocarte en construir una vida llena de propósito, alegría y significado.</p>
          
          <Card className="border-red-200 dark:border-red-800">
            <CardHeader>
              <CardTitle>Módulo 6.1: Tus Brújulas Internas</CardTitle>
              <CardDescription>Ejercicio Práctico: Mis Valores y Lema Personal</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold mb-2">Paso 1: Identifica tus Valores</h4>
                  <p className="text-sm mb-2">¿Qué es lo más importante para ti en la vida? Ejemplos:</p>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-red-100 dark:bg-red-900 px-3 py-1 rounded-full text-sm">Honestidad</span>
                    <span className="bg-red-100 dark:bg-red-900 px-3 py-1 rounded-full text-sm">Creatividad</span>
                    <span className="bg-red-100 dark:bg-red-900 px-3 py-1 rounded-full text-sm">Amistad</span>
                    <span className="bg-red-100 dark:bg-red-900 px-3 py-1 rounded-full text-sm">Valentía</span>
                    <span className="bg-red-100 dark:bg-red-900 px-3 py-1 rounded-full text-sm">Familia</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-bold mb-2">Paso 2: Crea tu Lema Personal</h4>
                  <p className="text-sm mb-2">Una frase corta que te inspire. Ejemplos:</p>
                  <div className="bg-rose-50 dark:bg-rose-950 p-3 rounded-lg space-y-1 text-sm italic">
                    <p>💪 "Soy fuerte y puedo superar esto"</p>
                    <p>💖 "Elijo la amabilidad"</p>
                    <p>🌟 "Cada día es una nueva oportunidad"</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-rose-200 dark:border-rose-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Módulo 6.3: Conectando con tu Tribu
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Los seres humanos somos seres sociales. Tener buenas relaciones es clave para una vida feliz.</p>
              <div className="grid md:grid-cols-2 gap-3">
                <div className="bg-rose-50 dark:bg-rose-950 p-3 rounded-lg">
                  <h5 className="font-semibold mb-2">🤝 Mejorar relaciones existentes</h5>
                  <p className="text-sm">Aprende a comunicarte de forma efectiva</p>
                </div>
                <div className="bg-rose-50 dark:bg-rose-950 p-3 rounded-lg">
                  <h5 className="font-semibold mb-2">✨ Construir nuevas amistades</h5>
                  <p className="text-sm">Elige personas que sumen a tu vida</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    },
    {
      id: 5,
      title: "Fase 7: Despedida",
      icon: <Sparkles className="w-8 h-8" />,
      color: "from-indigo-500 to-purple-500",
      content: (
        <div className="space-y-6">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Despedida y Nuevos Comienzos
          </h2>
          <p className="text-lg">¡Has llegado al final de este viaje! Esta fase es para celebrar todo lo que has logrado y prepararte para seguir adelante.</p>
          
          <Card className="border-indigo-200 dark:border-indigo-800">
            <CardHeader>
              <CardTitle>Módulo 7.2: Una Carta de Compasión para Ti</CardTitle>
              <CardDescription>Ejercicio Práctico: Mi Carta de Compasión</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">Escribe una carta para ti mismo. Imagina que eres tu mejor amigo o un mentor sabio que te quiere incondicionalmente.</p>
              <div className="bg-indigo-50 dark:bg-indigo-950 p-4 rounded-lg space-y-3">
                <div>
                  <h5 className="font-semibold mb-1">✍️ En tu carta puedes:</h5>
                  <ul className="space-y-1 text-sm list-disc list-inside">
                    <li>Reconocer tu esfuerzo y valentía</li>
                    <li>Recordar tus fortalezas y habilidades aprendidas</li>
                    <li>Ofrecer palabras de aliento para momentos difíciles</li>
                    <li>Expresar el orgullo que sientes por ti mismo</li>
                  </ul>
                </div>
                <p className="text-sm italic">Guarda esta carta en un lugar especial y léela cada vez que necesites un recordatorio de lo increíble que eres.</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-purple-200 dark:border-purple-800 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950">
            <CardHeader>
              <CardTitle className="text-2xl">¡Felicidades! ¡Has completado tu viaje!</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-lg">Recuerda que este manual es una guía, y el camino de la vida sigue. Tienes las herramientas para navegarlo con más confianza y resiliencia.</p>
              <p className="text-xl font-bold text-center bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                ¡Confía en ti y sigue construyendo esa vida que vale la pena vivir!
              </p>
            </CardContent>
          </Card>
        </div>
      )
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 dark:from-gray-900 dark:via-purple-900 dark:to-indigo-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
            Manual DBT-PTSD para Adolescentes
          </h1>
          <p className="text-xl text-muted-foreground">Tu guía interactiva para entender y manejar emociones fuertes</p>
        </header>

        {/* Navigation Pills */}
        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {phases.map((phase) => (
            <Button
              key={phase.id}
              onClick={() => setCurrentPhase(phase.id)}
              variant={currentPhase === phase.id ? "default" : "outline"}
              className={`flex items-center gap-2 transition-all ${
                currentPhase === phase.id 
                  ? `bg-gradient-to-r ${phase.color} text-white hover:opacity-90` 
                  : ""
              }`}
            >
              {phase.icon}
              <span className="hidden sm:inline">{phase.title}</span>
            </Button>
          ))}
        </div>

        {/* Content */}
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-2xl border-2">
            <CardContent className="p-8">
              {phases[currentPhase].content}
            </CardContent>
          </Card>

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            <Button
              onClick={() => setCurrentPhase(Math.max(0, currentPhase - 1))}
              disabled={currentPhase === 0}
              variant="outline"
              size="lg"
            >
              ← Anterior
            </Button>
            <Button
              onClick={() => setCurrentPhase(Math.min(phases.length - 1, currentPhase + 1))}
              disabled={currentPhase === phases.length - 1}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:opacity-90"
            >
              Siguiente <ChevronRight className="ml-2" />
            </Button>
          </div>
        </div>

        {/* Footer */}
        <footer className="text-center mt-16 text-sm text-muted-foreground">
          <p>Basado en el Manual de Entrenamiento DBT-PTSD por Martin Bohus</p>
          <p className="mt-2">Adaptado para adolescentes con un enfoque visual y práctico</p>
        </footer>
      </div>
    </div>
  )
}

export default App

